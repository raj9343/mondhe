import pandas as pd
import numpy as np
df=pd.read_csv('/home/itsl1-12/Pranjal/AirQuality.csv',sep=',')
print(df)
df1=pd.read_csv('/home/itsl1-12/Pranjal/heart.csv',sep=',')
print(df1)

#removal of duplicates
rd=df1.drop_duplicates()
print(rd)

#removal of irrelevant data
na=df1.isnull()
print(na)

na=df1.isna()
print(na)

da=df1.dropna()
print(da)

#removal of outliers
def remove_outliers(df,columns,n_std):
    for col in columns:
        print('Working on columns:{}'.format(col))
        mean=df[col].mean()
        sd=df[col].std()
        df=df[(df[col]<=mean+(n_std*sd))]
    return df
print(df)


#correcting errors
print(df.columns.tolist())

#data Integration
print(pd.concat([df,df1]))

# data transformation
#group by
gb=df1.groupby(['age','sex'])
print(gb.first() )

#display histogram
import matplotlib.pyplot as plt  
df1['age'].hist()

plt.boxplot(df1)
plt.show()

plt.scatter(df1['age'],df1['sex'])
plt.show()


