import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sn
df=pd.read_csv('/home/itsl1-12/Pranjal/heart.csv',sep=',')
print(df)
df1=pd.read_csv('/home/itsl1-12/Pranjal/forestfires.csv',sep=',')
print(df1)


#1)Histogram Diagram
#Simple Histogram
plt.hist(df)
plt.show()
#Distributed Histogram
plt.figure(figsize=(8, 6))
plt.hist(df['age'], bins=10, edgecolor='black')
plt.xlabel('age')
plt.ylabel('sex')
plt.title('Age Distribution in Heart Dataset')
plt.grid(True)
plt.show()

# Boxplot
plt.boxplot(df)
plt.show()

#scatter
x=df['cp']
y=df['chol']
plt.scatter(x,y)
plt.xlabel('cp')
plt.ylabel('chol')
plt.title('scatter diagram')
plt.show()

#lineplot
df.trestbps.plot(kind="line", color="g", label="resting blood pressure",linewidth=1,alpha = 1,grid = True,linestyle = ':')
df.thalach.plot(kind="line", color="b", label="maximum heart rate achieved", linewidth=1,alpha = 1,grid = True,linestyle = ':')
plt.legend(loc='upper right')    
plt.xlabel('x axis')              
plt.ylabel('y axis')
plt.title('Line Plot')            
plt.show()

#barplot
sn.barplot(df['age'])
plt.show()

#Piechart
forest_labels = ['Evergreen forest', 'Deciduous forest']
forest_data = [75, 25]
plt.subplot(1, 2, 2)
plt.pie(forest_data, labels=forest_labels, autopct='%1.1f%%', startangle=90)
plt.title('Forest Dataset')
plt.tight_layout()
plt.show()

#heatmap
numerical_columns = df.select_dtypes(include=['number']).columns
correlation_matrix =df[numerical_columns].corr()
plt.figure(figsize=(10, 8))
sn.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Heatmap for Heart Dataset')
plt.show()
